var a = 1;
var b = 10;
document.write("El valor de la primera variable es: "+ a + "<br>");
document.write("El valor de la segunda variable es: "+ b + "<br>");
document.write("La suma de ambos valores es: "+ (a+b));