for(let i=1; i<7;i++){
    document.write("<h"+i+">Cabecera h"+i+"</h"+i+"><br>");
}