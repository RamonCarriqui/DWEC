var celsius = 25;
var fahrenheit = 90;

document.write("La temperatura en celsius es de "+celsius+"<br>");
document.write("La temperatura convertida en fahrenheit es de: "+(celsius*9/5 + 32) +"<br>");
document.write("La temperatura en fahrenheit es de: "+fahrenheit+"<br>");
document.write("La temperatura convertida a celsius es de: "+(fahrenheit-32)*5/9);