var radio = 10;
document.write("El radio es: "+ radio +"<br>");
document.write("La circunferencia es: "+ 2*3.1416*radio+"<br>");
document.write("El área es: "+3.1416*(radio*radio));