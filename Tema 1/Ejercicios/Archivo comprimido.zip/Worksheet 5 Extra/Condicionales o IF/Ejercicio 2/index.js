/*Muestra si eres mayor de edad*/
edad = prompt("Introduce tu edad");

if (edad < 18){
    alert("Eres menor de edad");
}else{
    alert("Eres mayor de edad");
}
