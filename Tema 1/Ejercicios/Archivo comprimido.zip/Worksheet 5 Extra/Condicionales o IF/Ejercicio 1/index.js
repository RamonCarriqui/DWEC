/*Determinar si el número introducido es par*/
numero = prompt("Introduce un número");

if (numero % 2 == 0){
    alert("Es par");
}else{
    alert("Es impar");
}