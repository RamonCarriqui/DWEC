/* Crea	un	script	que	pregunte	al	usuario	por	el	nombre	de	un	mes,	y	muestre	el	número	de	días	que	
tiene	el	mes*/

mes = prompt("Dime un mes del año");

switch(mes){
    case "Enero":
        alert("Tiene 31 días");
        break;
    case "Febrero":
        alert("Tiene 28 días");
        break;
    case "Marzo":
        alert("Tiene 31 días");
        break;
    case "Abril":
        alert("Tiene 30 días");
        break;
    case "Mayo":
        alert("Tiene 31 días");
        break;
    case "Junio":
        alert("Tiene 30 días");
        break;
    case "Agosto":
        alert("Tiene 31 días");
        break;
    case "Septiembre":
        alert("Tiene 30 días");
        break;
    case "Octubre":
        alert("Tiene 31 días");
        break;
    case "Noviembre":
        alert("TIene 30 días");
        break;
    case "Diciembre":
        alert("Tiene 31 días");
      
}