/*crea	un	script	que	reciba	la	edad	de	un	usuario	y	
determine	si	puede	jubilarse	o	no	(la	jubilación	se	
alcanza	con	67 años).*/

edad = prompt("Escribe tu edad");

 if (edad >= 67){
     alert("Ya puedes jubilarte"); 
}
else{
    alert("Todavía no has alcanzado edad suficiente");
}
