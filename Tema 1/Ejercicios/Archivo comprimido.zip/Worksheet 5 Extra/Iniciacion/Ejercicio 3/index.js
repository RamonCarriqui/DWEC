/*Muestra una ventana emergente que diga hola y tu nombre, pidiéndolo
antes y utilizando concatenación*/ 

nombre = prompt("Dime tu nombre: ");
alert("Hola "+ nombre);