/*Script que pregunta nombre, apellidos y tu edad
y los muestra en la página web en párrafos distintos*/ 

nombre = prompt("Dime tu nombre: ");
apellidos = prompt("Escribe tus apellidos: ");
edad = prompt("Dime tu edad: ");

document.write(nombre +"<br>");
document.write(apellidos +"<br>");
document.write(edad);