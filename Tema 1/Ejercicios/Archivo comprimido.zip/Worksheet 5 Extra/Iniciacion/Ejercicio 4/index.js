/*Script que pide tu nombre, apellidos, edad y ciclo que estudias, y
muestra esa información en una ventan emergente*/ 

nombre = prompt("Dime tu nombre: ");
apellidos = prompt("Dime tus apellidos: ");
edad = prompt("Dime tu edad: ");
estudios = prompt("¿Qué estudias? ");

alert(nombre+"\n"+apellidos+"\n"+edad+"\n"+estudios);
